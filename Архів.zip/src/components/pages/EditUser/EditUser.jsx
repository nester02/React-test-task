import { useState } from "react";
import {useDispatch, useSelector} from "react-redux";
import './EditUser.css';
import { Select, Input} from "antd";
import {updateUser} from "../../../redux/slices/userSlice";

const EditUser = () => {
    const dispatch = useDispatch();
    const [selectedUser, setSelectedUser] = useState("");
    const [userName, setUserName] = useState("");
    const [userDepartment, setUserDepartment] = useState("");
    const [userCountry, setUserCountry] = useState("");
    const [userStatus, setUserStatus] = useState("");

    const users = useSelector(store => store.user.users);
    const departments = useSelector(store => store.department.departments);
    const countries = useSelector(store => store.country.countries);
    const statuses = useSelector(store => store.status.statuses);

    const handleSelectChange = (value) => {
        setSelectedUser(value);
    };

    const handleNameChange = (e) => {
        setUserName(e.target.value);
    };

    const handleDepartmentChange = (value) => {
        setUserDepartment(value);
    };

    const handleCountryChange = (value) => {
        setUserCountry(value);
    }

    const handleStatusChange = (value) => {
        setUserStatus(value);
    }

    const handleSaveClick = () => {
        if (selectedUser) {
            console.log("Dispatching updateUser:", {
                id: selectedUser,
                name: userName,
                department: userDepartment,
                country: userCountry,
                status: userStatus,
            });
            dispatch (
                updateUser ({
                    name: userName,
                    department: userDepartment,
                    country: userCountry,
                    status: userStatus,
                })
            )
        }
    }

    const handleUndoClick = () => {
        setSelectedUser('');
        setUserName('');
        setUserCountry('');
        setUserDepartment('');
        setUserStatus('');
    }

    const options = users.map(user => ({
        value: user.id,
        label: user.name
    }));

    const departmentOptions = departments.map(department => ({
        value: department.id,
        label: department.name
    }));

    const countryOptions = countries.map(country => ({
        value: country.id,
        label: country.name
    }));

    const statusOptions = statuses.map(status => ({
        value: status.id,
        label: status.name,
    }));

    return (
        <section className="edit">
            <div className="__container --edit__container">
                <h1 className="section__heading --edit__heading">Edit user</h1>
                <div className="edit__select --edit__select-user">
                    <div className="section__description --edit__description">User</div>
                    <Select
                        showSearch
                        style={{width: 500, height: 48, }}
                        onChange={handleSelectChange}
                        placeholder="Enter user name"
                        optionFilterProp="label"
                        filterOption={(input, option) =>
                            (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                        }
                        filterSort={(optionA, optionB) =>
                            (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                        }
                        options={options}
                    />
                </div>
                <h2 className="information__heading">User Information</h2>
                <div className="edit__user-information">
                    <div className="information__row-first">
                        <div className="section__description --edit__description">Full Name</div>
                        <Input placeholder="Username" onChange={handleNameChange} value={userName}
                               style={{width: 500, marginBottom: 40, height: 48,}}/>

                        <div className="section__description --edit__description">Department</div>
                        <Select
                            showSearch
                            style={{width: 500, height: 48,}}
                            onChange={handleDepartmentChange}
                            value={userDepartment}
                            placeholder="Enter user department"
                            optionFilterProp="label"
                            filterOption={(input, option) =>
                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                            }
                            filterSort={(optionA, optionB) =>
                                (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                            }
                            options={departmentOptions}
                        />
                    </div>

                    <div className="information__row-second">
                        <div className="section__description --edit__description">Country</div>
                        <Select
                            showSearch
                            style={{width: 500, marginBottom: 40, height: 48,}}
                            onChange={handleCountryChange}
                            value={userCountry}
                            placeholder="Enter user country"
                            optionFilterProp="label"
                            filterOption={(input, option) =>
                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                            }
                            filterSort={(optionA, optionB) =>
                                (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                            }
                            options={countryOptions}
                        />

                        <div className="section__description --edit__description">Status</div>
                        <Select
                            showSearch
                            style={{width: 500, height: 48,}}
                            onChange={handleStatusChange}
                            value={userStatus}
                            placeholder="Enter user status"
                            optionFilterProp="label"
                            filterOption={(input, option) =>
                                (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
                            }
                            filterSort={(optionA, optionB) =>
                                (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                            }
                            options={statusOptions}
                        />
                    </div>
                </div>

                <div className="edit__buttons">
                    <button onClick={handleUndoClick} className="button__undo">Undo</button>
                    <button onClick={handleSaveClick} className="button__save">Save</button>
                </div>
            </div>
        </section>
    );
};

export default EditUser;
