# React-test-task
Test task from a Nesterchuk M.S. for Insiders
